import WxPage from '../../commons/Page'

class ComponentPage extends WxPage{
    
}
new ComponentPage().init()
